二维码扫描器（iPhone 网页 App）
=============================

功能：
- 二维码内容作为唯一 ID
- 第一次扫描才计数
- 同一二维码再次扫描不增加唯一数量
- 重复扫描语音播报“重复扫描”
- 扫描成功语音播报“扫描成功”
- 自动连续扫描，无需每次点击
- localStorage 本地保存
- 导出 CSV

使用：
1. 将这几个文件部署到 HTTPS 网站（例如 GitHub Pages、Cloudflare Pages、Netlify 等）。
2. 用 iPhone Safari 打开。
3. 允许摄像头权限。
4. 点击“开始扫描”。
5. 可通过 Safari 的“添加到主屏幕”作为网页 App 使用。

注意：
- 摄像头通常要求 HTTPS（localhost 开发环境除外）。
- CSV 可以用 Numbers、Excel 等打开。
- 数据保存在当前浏览器/网站的本地存储中；清除 Safari 网站数据可能导致记录丢失。
